import { exposeElectronAPI } from '@electron-toolkit/preload'

exposeElectronAPI()